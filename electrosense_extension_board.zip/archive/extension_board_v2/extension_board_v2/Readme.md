## Electrosense frequency converter board

The board is ment to be connected to the sensor to extend its frequency range from DC to 6GHz.
The design is made with Altium Designer 17.

The BOM_final.xlsx file contains all the components with their respective Farnell or Mouser order code.
